from pystyle import Center, Colors, Colorate
import json
import requests
import os
import sys

os.system(f"title Plexy Draw - DARK BASK ;)")

Banner_logo = fr"""

     /$$$$$$$                      /$$             /$$$$$$$   /$$$$$$  /$$   /$$
    | $$__  $$                    | $$            | $$__  $$ /$$__  $$| $$  /$$/
    | $$  \ $$  /$$$$$$   /$$$$$$ | $$   /$$      | $$  \ $$| $$  \__/| $$ /$$/ 
    | $$  | $$ |____  $$ /$$__  $$| $$  /$$/      | $$$$$$$ |  $$$$$$ | $$$$$/  
    | $$  | $$  /$$$$$$$| $$  \__/| $$$$$$/       | $$__  $$ \____  $$| $$  $$  
    | $$  | $$ /$$__  $$| $$      | $$_  $$       | $$  \ $$ /$$  \ $$| $$\  $$ 
    | $$$$$$$/|  $$$$$$$| $$      | $$ \  $$      | $$$$$$$/|  $$$$$$/| $$ \  $$
    |_______/  \_______/|__/      |__/  \__/      |_______/  \______/ |__/  \__/

                          Developed by Plexy-draw 2024 © 

""" 
Name_text = """
┌═══════════════════════════════════════┐ 
█ Ingresa: Nombre, Apellido, Dni o Cuit █
└═══════════════════════════════════════┘"""
Name_arch ="""
┌═══════════════════════════════┐ 
█ Ingresa el Nombre del archivo █
└═══════════════════════════════┘""" 
opts = """
┌═════════════════════════════════════════════════┐ 
█ [ 1 ] Buscar [ 2 ] Salir [ 3 ] Guardar Busqueda █
└═════════════════════════════════════════════════┘"""
tip = """
┌══════════════════════════════════════════┐ 
█ [ -1 ] Todos [ 1 ] Empresa [ 2 ] Persona █
└══════════════════════════════════════════┘"""
edad_s = """
┌══════════════════════════════════════════════┐ 
█ [ 0 ] Todas las edades [ 1 ] edad especifica █
└══════════════════════════════════════════════┘"""
ed_d = """
┌═════════════════════┐ 
█ Edad desde (Min 18) █
└═════════════════════┘"""
ed_h = """
┌══════════════════════┐ 
█ Edad hasta (Max 100) █
└══════════════════════┘"""
prov = """
┌═════════════════════════════════════════════════════════════════════════┐ 
█ [ -1 ] Todas        [ 0 ] Capital Federal    [ 1 ] Buenos Aires         █
█ [ 2 ] Catamarca     [ 3 ] Córdoba            [ 4 ] Corrientes           █
█ [ 5 ] Entre Ríos    [ 6 ] Jujuy              [ 7 ] Mendoza              █
█ [ 8 ] La Rioja      [ 9 ] Formosa            [ 10 ] Salta               █
█ [ 11 ] San Luis     [ 12 ] Santa Cruz        [ 13 ] Santiago del Estero █
█ [ 14 ] Tucumán      [ 15 ] Neuquén           [ 16 ] Chaco               █
█ [ 17 ] Chubut       [ 18 ] San Juan          [ 19 ] Misiones            █
█ [ 20 ] Río Negro    [ 21 ] La Pampa          [ 22 ] Santa Fe            █
█ [ 23 ] Tierra del Fuego                                                 █
└═════════════════════════════════════════════════════════════════════════┘
"""
local_txt = """
┌══════════════════════════════════════════════════════════════┐ 
█ Ingresa la localidad (EJ: saladillo) o deja este campo vacio █
└══════════════════════════════════════════════════════════════┘""" 

def Banner():
    print(Colorate.Vertical(Colors.green_to_yellow, Center.XCenter(Banner_logo)))

def obtener_config_post():

    def obtener_name():
        try:
            print(Colorate.Vertical(Colors.green_to_black, Name_text, 3)) 
            nombre = input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2))
        except Exception:
            print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
        return nombre
    
    def obtener_tipo():
        while True:
            try:
                print(Colorate.Vertical(Colors.green_to_black, tip, 3)) 
                tipo = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
                if tipo >= -1 and tipo <= 2:
                    if tipo == 1:
                        tipo = "E"
                    elif tipo == 2:
                        tipo == "P"
                    break
                else:
                    print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: El Numero ingresado esta fuera de rango.")
            except Exception as e:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
        return tipo
    
    def obtener_edad():
        while True:
            try:
                print(Colorate.Vertical(Colors.green_to_black, edad_s, 3))
                se = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
                match se:
                    case 0:
                        se = -1 
                        edad_desde = -1
                        edad_hasta = -1 
                        break
                    case 1:
                        while True:
                            try:
                                print(Colorate.Vertical(Colors.green_to_black, ed_d, 3)) 
                                edad_desde = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
                                if edad_desde >= 18 and edad_desde <= 100:
                                    break
                            except Exception:
                                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
                        while True:
                            try:
                                print(Colorate.Vertical(Colors.green_to_black, ed_h, 3)) 
                                edad_hasta = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
                                if edad_hasta >= 18 and edad_hasta <= 100:
                                    break
                            except Exception:
                                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
                        break
                    case _:
                        print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: El Numero ingresado esta fuera de rango.")
            except Exception:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")

        return edad_desde,edad_hasta, se
    
    def obtener_provincia():
        while True:
            try:
                print(Colorate.Vertical(Colors.green_to_yellow, prov, 3)) 
                provincia = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
                if provincia >= -1 and provincia <= 24:
                    break
                else:
                    print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: El Numero ingresado esta fuera de rango.")
            except Exception as e:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
        return provincia
    
    def obtener_localidad():
        try:
            print(Colorate.Vertical(Colors.green_to_black, local_txt , 3)) 
            localidad = input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2))
        except Exception:
            print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato.")
        return localidad

    nombre = obtener_name()
    tipo = obtener_tipo()
    edad_desde, edad_hasta, selec = obtener_edad()
    provincia = obtener_provincia()
    localidad = obtener_localidad()

    api = 'https://informes.nosis.com/Home/Buscar'


    try: 
        with open(f'{directorio_actual_c}\\Config_Program\\config.json', 'r') as file:
            data = json.load(file)

            headers = data['headers']
            cookies = data['cookies']
            form_data = {
                "Texto": f"{nombre}",
                "Tipo": f"{tipo}",
                "EdadDesde": f"{edad_desde}",
                "EdadHasta": f"{edad_hasta}",
                "IdProvincia": f"{provincia}",
                "Localidad": f"{localidad}",
                # Los campos relacionados con el captcha se eliminan
                # "recaptcha_response_field": "enganio+al+captcha",
                # "recaptcha_challenge_field": "enganio+al+captcha",
                # "encodedResponse": "",
                "Pagina": "1"
            }
    
    except Exception as e:
        print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + f" Error: al obtener las configuraciones de config.json. {e}")

    return api, headers, cookies, form_data

def Realizar_Solicitud(data,headers,cookies,url):
    all_results = []
    pagina = 1
    hay_mas_resultados = True
    print(Colorate.Vertical(Colors.green_to_black, "    [ + ]",2) + f' Buscando...')

    while hay_mas_resultados:
        try:
            data['Pagina'] = str(pagina)
            response = requests.post(url, headers=headers, cookies=cookies, data=data)
            try:
                json_response = response.json()
                if json_response.get('EntidadesEncontradas'):
                    all_results.extend(json_response['EntidadesEncontradas'])
                hay_mas_resultados = json_response.get('HayMasResultados', False)
                pagina += 1
            except ValueError:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + f" Error: La respuesta no es un JSON.")
                hay_mas_resultados = False  
            except TypeError:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + f" Error: al procesar la página {pagina}.")
                hay_mas_resultados = False  
            except Exception:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + f" Error: al intentar el post.")
        except Exception:
            print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + f" Error: al realizar la solicitud post.")
            continue
    print(Colorate.Vertical(Colors.green_to_black, "    [ + ]",2) + f' Se procesaron {pagina} paginas.')
    return all_results

def Mostrar_Resultados(results):
    contenido = ""
    contenido_sin_color = ""
    
    if len(results) == 0:
        print(Colorate.Vertical(Colors.green_to_black, "    [ + ]", 2) + f' Total de resultados obtenidos: {len(results)}.')
        print(Colorate.Vertical(Colors.green_to_black, "    [ + ]", 2) + f' En caso de obtener 0 resultados verifica la informacion ingresada o activa un vpn.\n')
    else:
        print(Colorate.Vertical(Colors.green_to_black, "    [ + ]", 2) + f' Total de resultados obtenidos: {len(results)}.\n')
    
    for idx, entidad in enumerate(results, start=1):
        documento = entidad.get('Documento', 'N/A')
        partes = documento.split('-')
        dni = partes[1] if len(partes) > 2 else 'N/A'
        
        contenido += Colorate.Vertical(Colors.green_to_black, "    [ + ]", 2) + f" Entidad {idx}:\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Cuit          : {documento}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Documento     : {dni}\n"          
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Razon Social  : {entidad.get('RazonSocial', 'N/A')}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Actividad     : {entidad.get('Actividad', 'N/A')}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Provincia     : {entidad.get('Provincia', 'N/A')}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Url Informe   : {entidad.get('UrlInforme', 'N/A')}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Url Clon      : {entidad.get('UrlClon', 'N/A')}\n"
        contenido += Colorate.Vertical(Colors.green_to_black, "         [ - ]", 2) + f" Habeas Data   : {entidad.get('MensajeHabeasData', 'N/A')}\n"
        contenido += "\n"
        
        contenido_sin_color += f"[ + ] Entidad {idx}:\n"
        contenido_sin_color += f"     [ - ] Cuit          : {documento}\n"
        contenido_sin_color += f"     [ - ] Documento     : {dni}\n"
        contenido_sin_color += f"     [ - ] Razon Social  : {entidad.get('RazonSocial', 'N/A')}\n"
        contenido_sin_color += f"     [ - ] Actividad     : {entidad.get('Actividad', 'N/A')}\n"
        contenido_sin_color += f"     [ - ] Provincia     : {entidad.get('Provincia', 'N/A')}\n"
        contenido_sin_color += f"     [ - ] Url Informe   : {entidad.get('UrlInforme', 'N/A')}\n"
        contenido_sin_color += f"     [ - ] Url Clon      : {entidad.get('UrlClon', 'N/A')}\n"
        contenido_sin_color += f"     [ - ] Habeas Data   : {entidad.get('MensajeHabeasData', 'N/A')}\n"
        contenido_sin_color += "\n"
    
    print(contenido)
    return contenido_sin_color

def obtener_directorio_actual():
    try:
        directorio_actual = os.getcwd()
        carpeta_historial = os.path.join(directorio_actual, 'Historial')
        if not os.path.exists(carpeta_historial):
            os.makedirs(carpeta_historial)
        return carpeta_historial, directorio_actual
    except Exception:
        print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: No se pudo obtener el directorio actual.")
directorio_actual, directorio_actual_c = obtener_directorio_actual()

def guardar_en_archivo(contenido):
    print(Colorate.Vertical(Colors.green_to_black, Name_arch, 3)) 
    nombre_archivo = input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2))
    try:
        with open(f"{directorio_actual}/{nombre_archivo}.txt", 'w') as archivo:
            archivo.write(contenido)
        print(Colorate.Vertical(Colors.green_to_black, "    [ + ]",2) + f" Los datos se han guardado en '{nombre_archivo}.txt'.")
    except Exception:
        print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: No se pudo guardar el archivo.")

def consultar(cont):
    while True:
        print(Colorate.Vertical(Colors.green_to_black, opts, 3)) 
        try:
            selec = int(input(Colorate.Vertical(Colors.green_to_black, "└═>>>  ", 2)))
            match selec:
                case 1:
                    os.system("cls")
                    main()
                case 2:
                    os.system("cls")
                    sys.exit()
                case 3:
                    print(Colorate.Vertical(Colors.green_to_black, "    [ + ]",2) + f" directorio de almacenamiento: '{directorio_actual}'.")
                    guardar_en_archivo(cont)
                case _:
                    print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: El Numero ingresado esta fuera de rango.")
        except Exception as e:
                print(Colorate.Vertical(Colors.red_to_purple, "[ - ]",2) + " Error: de tipo de dato." + e)

def main():
    Banner()
    api,headers,cookies,data = obtener_config_post()
    results = Realizar_Solicitud(data,headers,cookies,api)
    contenido = Mostrar_Resultados(results)
    consultar(contenido)

if __name__ == "__main__":
    main()